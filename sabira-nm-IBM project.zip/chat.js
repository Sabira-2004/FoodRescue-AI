/* ============================================================
   chat.js — "Ask Studio" AI tutor
   Calls the Anthropic API directly from the browser using a key
   the user pastes in and stores only in localStorage.
   ============================================================ */

let chatHistory = []; // { role: 'user'|'assistant', content: string }

function getApiKey(){
  return localStorage.getItem('sa_api_key') || '';
}

function renderKeyStatus(){
  const status = document.getElementById('keyStatus');
  status.textContent = getApiKey() ? 'Key saved ✓' : 'No key saved yet';
}

document.getElementById('saveKeyBtn').addEventListener('click', () => {
  const val = document.getElementById('apiKeyInput').value.trim();
  if(val){
    localStorage.setItem('sa_api_key', val);
    document.getElementById('apiKeyInput').value = '';
  }
  renderKeyStatus();
});

function addMessage(role, text){
  const wrap = document.getElementById('chatMessages');
  const el = document.createElement('div');
  el.className = 'chat-msg ' + (role === 'user' ? 'chat-user' : 'chat-bot');
  el.textContent = text;
  wrap.appendChild(el);
  wrap.scrollTop = wrap.scrollHeight;
}

function buildStudyContext(){
  // Give the assistant light context: subjects the user has notes on.
  const subjects = [...new Set(State.notes.map(n => n.subject).filter(Boolean))];
  if(subjects.length === 0) return '';
  return `The student is currently studying: ${subjects.join(', ')}.`;
}

async function sendChat(message){
  const apiKey = getApiKey();
  if(!apiKey){
    addMessage('assistant', 'Add an API key in the panel below first — see the README for where to get one.');
    return;
  }

  chatHistory.push({ role: 'user', content: message });
  const sendBtn = document.getElementById('chatSendBtn');
  sendBtn.disabled = true;
  sendBtn.textContent = '...';

  try{
    const res = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-6',
        max_tokens: 700,
        system: `You are Studio, a concise, encouraging study assistant embedded in a learning app. ${buildStudyContext()} Explain clearly, use short paragraphs or lists, and offer to quiz the student when relevant.`,
        messages: chatHistory
      })
    });

    if(!res.ok){
      const errBody = await res.text();
      throw new Error(`API error ${res.status}: ${errBody.slice(0,200)}`);
    }

    const data = await res.json();
    const textBlock = (data.content || []).find(b => b.type === 'text');
    const reply = textBlock ? textBlock.text : "I didn't get a text response back — try again.";
    chatHistory.push({ role: 'assistant', content: reply });
    addMessage('assistant', reply);
  } catch(err){
    addMessage('assistant', `Something went wrong talking to the API: ${err.message}`);
  } finally {
    sendBtn.disabled = false;
    sendBtn.textContent = 'Send';
  }
}

document.getElementById('chatForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if(!msg) return;
  addMessage('user', msg);
  input.value = '';
  sendChat(msg);
});

document.getElementById('chatInput').addEventListener('keydown', (e) => {
  if(e.key === 'Enter' && !e.shiftKey){
    e.preventDefault();
    document.getElementById('chatForm').requestSubmit();
  }
});

document.addEventListener('DOMContentLoaded', renderKeyStatus);
