/* ============================================================
   notes.js — note taking
   ============================================================ */

let activeNoteId = null;

function renderNotesList(){
  const list = document.getElementById('notesList');
  list.innerHTML = '';
  const sorted = [...State.notes].sort((a,b) => b.updatedAt - a.updatedAt);

  if(sorted.length === 0){
    list.innerHTML = '<p class="muted" style="padding:.5em;">No notes yet — start one.</p>';
  }

  sorted.forEach(n => {
    const el = document.createElement('div');
    el.className = 'note-item' + (n.id === activeNoteId ? ' is-active' : '');
    el.innerHTML = `<span class="n-title">${escapeHtml(n.title || 'Untitled')}</span><span class="n-sub">${escapeHtml(n.subject || 'No subject')}</span>`;
    el.addEventListener('click', () => loadNote(n.id));
    list.appendChild(el);
  });
}
window.renderNotesList = renderNotesList;

function loadNote(id){
  const note = State.notes.find(n => n.id === id);
  if(!note) return;
  activeNoteId = id;
  document.getElementById('noteTitle').value = note.title || '';
  document.getElementById('noteSubject').value = note.subject || '';
  document.getElementById('noteBody').value = note.body || '';
  document.getElementById('notesHint').textContent = '';
  renderNotesList();
}

function newNote(){
  activeNoteId = null;
  document.getElementById('noteTitle').value = '';
  document.getElementById('noteSubject').value = '';
  document.getElementById('noteBody').value = '';
  document.getElementById('noteTitle').focus();
  document.getElementById('notesHint').textContent = '';
  renderNotesList();
}

function saveNote(){
  const title = document.getElementById('noteTitle').value.trim();
  const subject = document.getElementById('noteSubject').value.trim();
  const body = document.getElementById('noteBody').value;

  if(!title && !body.trim()){
    document.getElementById('notesHint').textContent = 'Write something before saving.';
    return;
  }

  if(activeNoteId){
    const note = State.notes.find(n => n.id === activeNoteId);
    note.title = title; note.subject = subject; note.body = body; note.updatedAt = Date.now();
  } else {
    const note = { id: uid(), title, subject, body, createdAt: Date.now(), updatedAt: Date.now() };
    State.notes.push(note);
    activeNoteId = note.id;
  }
  saveNotes();
  bumpStreak();
  renderNotesList();
  document.getElementById('notesHint').textContent = 'Saved.';
  setTimeout(() => { const h = document.getElementById('notesHint'); if(h.textContent === 'Saved.') h.textContent = ''; }, 1500);
}

function deleteNote(){
  if(!activeNoteId) return;
  State.notes = State.notes.filter(n => n.id !== activeNoteId);
  saveNotes();
  newNote();
  renderNotesList();
}

/* Turn a note's lines into rough flashcards.
   Supports "Question :: Answer" or "Term - Definition" per line;
   otherwise falls back to one card per non-empty line asking the
   user to recall it, with the line as the answer. */
function makeCardsFromNote(){
  const subject = document.getElementById('noteSubject').value.trim() || 'General';
  const body = document.getElementById('noteBody').value;
  const lines = body.split('\n').map(l => l.trim()).filter(Boolean);

  if(lines.length === 0){
    document.getElementById('notesHint').textContent = 'Nothing to turn into cards yet.';
    return;
  }

  let created = 0;
  lines.forEach(line => {
    let front, back;
    if(line.includes('::')){
      [front, back] = line.split('::').map(s => s.trim());
    } else if(/ - /.test(line)){
      [front, back] = line.split(/ - (.+)/).map(s => s && s.trim());
    } else {
      return; // skip plain lines with no clear Q/A structure
    }
    if(front && back){
      State.cards.push({
        id: uid(), deck: subject, front, back,
        interval: 0, ease: 2.3, due: Date.now(), reps: 0
      });
      created++;
    }
  });

  saveCards();
  if(created > 0){
    document.getElementById('notesHint').textContent = `Created ${created} flashcard${created>1?'s':''}. Use "Term :: Definition" per line for best results.`;
  } else {
    document.getElementById('notesHint').textContent = 'No "Term :: Definition" or "Term - Definition" lines found. Add lines in that format, then try again.';
  }
}

document.getElementById('newNoteBtn').addEventListener('click', newNote);
document.getElementById('saveNoteBtn').addEventListener('click', saveNote);
document.getElementById('deleteNoteBtn').addEventListener('click', deleteNote);
document.getElementById('makeCardsBtn').addEventListener('click', makeCardsFromNote);
