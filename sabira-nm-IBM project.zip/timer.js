/* ============================================================
   timer.js — focus / break pomodoro-style timer
   ============================================================ */

const RING_CIRCUMFERENCE = 565.5;

let focusLen = 25, breakLen = 5;
let mode = 'Focus';
let secondsLeft = focusLen * 60;
let totalSeconds = focusLen * 60;
let tickHandle = null;
let running = false;

function fmt(sec){
  const m = Math.floor(sec / 60).toString().padStart(2,'0');
  const s = (sec % 60).toString().padStart(2,'0');
  return `${m}:${s}`;
}

function renderTimer(){
  document.getElementById('timerDisplay').textContent = fmt(secondsLeft);
  document.getElementById('timerMode').textContent = mode;
  const ratio = secondsLeft / totalSeconds;
  document.getElementById('ringFg').style.strokeDashoffset = RING_CIRCUMFERENCE * (1 - ratio);
  renderSessionCount();
}

function renderSessionCount(){
  const today = todayKey();
  if(State.sessionsToday.date !== today){
    State.sessionsToday = { date: today, count: 0 };
    saveSessionsToday();
  }
  document.getElementById('sessionCount').textContent =
    `${State.sessionsToday.count} focus session${State.sessionsToday.count === 1 ? '' : 's'} completed today`;
}

function tick(){
  secondsLeft--;
  if(secondsLeft < 0){
    handleIntervalComplete();
    return;
  }
  renderTimer();
}

function handleIntervalComplete(){
  if(mode === 'Focus'){
    State.focusMinutes += focusLen;
    saveFocusMinutes();
    State.sessionsToday.count += 1;
    saveSessionsToday();
    bumpStreak();
    mode = 'Break';
    totalSeconds = breakLen * 60;
  } else {
    mode = 'Focus';
    totalSeconds = focusLen * 60;
  }
  secondsLeft = totalSeconds;
  renderTimer();
  renderDashboard();
  // gentle audible cue
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const osc = ctx.createOscillator();
    osc.frequency.value = mode === 'Break' ? 440 : 660;
    osc.connect(ctx.destination);
    osc.start(); osc.stop(ctx.currentTime + 0.18);
  }catch(e){ /* audio not available, ignore */ }
}

function startPause(){
  running = !running;
  document.getElementById('timerStartBtn').textContent = running ? 'Pause' : 'Start';
  if(running){
    tickHandle = setInterval(tick, 1000);
  } else {
    clearInterval(tickHandle);
  }
}

function resetTimer(){
  running = false;
  clearInterval(tickHandle);
  document.getElementById('timerStartBtn').textContent = 'Start';
  mode = 'Focus';
  totalSeconds = focusLen * 60;
  secondsLeft = totalSeconds;
  renderTimer();
}

document.getElementById('timerStartBtn').addEventListener('click', startPause);
document.getElementById('timerResetBtn').addEventListener('click', resetTimer);

document.querySelectorAll('.len-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.len-btn').forEach(b => b.classList.remove('is-active'));
    btn.classList.add('is-active');
    focusLen = parseInt(btn.dataset.focus, 10);
    breakLen = parseInt(btn.dataset.break, 10);
    resetTimer();
  });
});

document.addEventListener('DOMContentLoaded', renderTimer);
