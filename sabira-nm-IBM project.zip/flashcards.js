/* ============================================================
   flashcards.js — deck management + spaced-repetition study
   ============================================================ */

let studyQueue = [];
let studyIndex = 0;
let currentFilterDeck = 'all';

function deckNames(){
  return [...new Set(State.cards.map(c => c.deck))].sort();
}

function dueCards(deck){
  const now = Date.now();
  return State.cards.filter(c => c.due <= now && (deck === 'all' || !deck || c.deck === deck));
}
window.dueCards = () => dueCards('all');

function refreshDeckSelects(){
  ['deckFilter', 'quizDeck'].forEach(id => {
    const sel = document.getElementById(id);
    const current = sel.value;
    sel.innerHTML = '<option value="all">All decks</option>' +
      deckNames().map(d => `<option value="${escapeHtml(d)}">${escapeHtml(d)}</option>`).join('');
    if([...sel.options].some(o => o.value === current)) sel.value = current;
  });
}

function renderFlashcards(){
  refreshDeckSelects();
  renderCardsTable();
  startStudyQueue(currentFilterDeck, false);
}
window.renderFlashcards = renderFlashcards;

function renderCardsTable(){
  const wrap = document.getElementById('cardsTable');
  wrap.innerHTML = '';
  if(State.cards.length === 0){
    wrap.innerHTML = '<p class="muted">No flashcards yet. Add one, or create some from a note.</p>';
    return;
  }
  State.cards.forEach(c => {
    const row = document.createElement('div');
    row.className = 'card-row';
    row.innerHTML = `
      <span>${escapeHtml(c.front)}</span>
      <span>${escapeHtml(c.back)}</span>
      <span class="cr-deck">${escapeHtml(c.deck)}</span>
      <button data-id="${c.id}">Delete</button>
    `;
    row.querySelector('button').addEventListener('click', () => {
      State.cards = State.cards.filter(x => x.id !== c.id);
      saveCards();
      renderFlashcards();
    });
    wrap.appendChild(row);
  });
}

function startStudyQueue(deck, includeAllRegardless){
  const pool = includeAllRegardless
    ? State.cards.filter(c => deck === 'all' || c.deck === deck)
    : dueCards(deck);
  studyQueue = shuffle([...pool]);
  studyIndex = 0;
  renderStudyCard();
}

function shuffle(arr){
  for(let i = arr.length - 1; i > 0; i--){
    const j = Math.floor(Math.random() * (i+1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function renderStudyCard(){
  const empty = document.getElementById('fcEmpty');
  const cardEl = document.getElementById('flashCard');

  if(studyQueue.length === 0 || studyIndex >= studyQueue.length){
    empty.hidden = false;
    cardEl.hidden = true;
    return;
  }
  empty.hidden = true;
  cardEl.hidden = false;

  const c = studyQueue[studyIndex];
  document.getElementById('cardPos').textContent = studyIndex + 1;
  document.getElementById('cardTotal').textContent = studyQueue.length;
  document.getElementById('cardDeck').textContent = c.deck;
  document.getElementById('cardFront').textContent = c.front;
  document.getElementById('cardBack').textContent = c.back;
  document.getElementById('cardBack').hidden = true;
  document.getElementById('flipBtn').hidden = false;
  document.getElementById('rateRow').hidden = true;
}

document.getElementById('flipBtn').addEventListener('click', () => {
  document.getElementById('cardBack').hidden = false;
  document.getElementById('flipBtn').hidden = true;
  document.getElementById('rateRow').hidden = false;
});

document.getElementById('rateRow').addEventListener('click', (e) => {
  const btn = e.target.closest('[data-grade]');
  if(!btn) return;
  gradeCard(studyQueue[studyIndex], btn.dataset.grade);
  studyIndex++;
  renderStudyCard();
  renderDashboard();
});

/* Simplified SM-2-style spacing:
   again -> reset interval to 0 (due immediately)
   good  -> interval grows by ease factor (in days)
   easy  -> interval grows faster, ease factor nudges up */
function gradeCard(card, grade){
  card.reps = (card.reps || 0) + 1;
  if(grade === 'again'){
    card.interval = 0;
    card.ease = Math.max(1.3, (card.ease || 2.3) - 0.2);
  } else if(grade === 'good'){
    card.interval = card.interval ? Math.round(card.interval * (card.ease || 2.3)) : 1;
    card.ease = card.ease || 2.3;
  } else if(grade === 'easy'){
    card.interval = card.interval ? Math.round(card.interval * (card.ease || 2.3) * 1.3) : 3;
    card.ease = (card.ease || 2.3) + 0.15;
  }
  const dayMs = 86400000;
  card.due = Date.now() + (grade === 'again' ? 60000 : card.interval * dayMs);
  saveCards();
}

document.getElementById('deckFilter').addEventListener('change', (e) => {
  currentFilterDeck = e.target.value;
  startStudyQueue(currentFilterDeck, false);
});

document.getElementById('reviewAnywayBtn').addEventListener('click', () => {
  startStudyQueue(currentFilterDeck, true);
});

document.getElementById('addCardBtn').addEventListener('click', () => {
  const deck = prompt('Deck / subject name:', deckNames()[0] || 'General');
  if(deck === null) return;
  const front = prompt('Front (question / term):');
  if(!front) return;
  const back = prompt('Back (answer / definition):');
  if(!back) return;
  State.cards.push({
    id: uid(), deck: deck.trim() || 'General', front: front.trim(), back: back.trim(),
    interval: 0, ease: 2.3, due: Date.now(), reps: 0
  });
  saveCards();
  renderFlashcards();
  renderDashboard();
});
