/* ============================================================
   app.js — navigation, storage helpers, dashboard
   ============================================================ */

const Store = {
  get(key, fallback){
    try{
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }catch(e){ return fallback; }
  },
  set(key, value){
    localStorage.setItem(key, JSON.stringify(value));
  }
};

const State = {
  notes: Store.get('sa_notes', []),
  cards: Store.get('sa_cards', []),
  focusMinutes: Store.get('sa_focus_minutes', 0),
  sessionsToday: Store.get('sa_sessions_today', { date: null, count: 0 }),
  streak: Store.get('sa_streak', { count: 0, lastDate: null })
};

function saveNotes(){ Store.set('sa_notes', State.notes); }
function saveCards(){ Store.set('sa_cards', State.cards); }
function saveFocusMinutes(){ Store.set('sa_focus_minutes', State.focusMinutes); }
function saveSessionsToday(){ Store.set('sa_sessions_today', State.sessionsToday); }
function saveStreak(){ Store.set('sa_streak', State.streak); }

function todayKey(){
  return new Date().toISOString().slice(0,10);
}

function bumpStreak(){
  const today = todayKey();
  if(State.streak.lastDate === today) return; // already counted today
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0,10);
  if(State.streak.lastDate === yesterday){
    State.streak.count += 1;
  } else {
    State.streak.count = 1;
  }
  State.streak.lastDate = today;
  saveStreak();
  renderStreak();
}

function renderStreak(){
  document.getElementById('streakCount').textContent = State.streak.count;
}

/* ---------- Navigation ---------- */
function goto(view){
  document.querySelectorAll('.nav-item').forEach(b => {
    b.classList.toggle('is-active', b.dataset.view === view);
  });
  document.querySelectorAll('.view').forEach(v => {
    v.classList.toggle('is-active', v.id === 'view-' + view);
  });
  if(view === 'dashboard') renderDashboard();
  if(view === 'flashcards' && window.renderFlashcards) window.renderFlashcards();
  if(view === 'quiz' && window.renderQuizSetup) window.renderQuizSetup();
  if(view === 'notes' && window.renderNotesList) window.renderNotesList();
}

document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => goto(btn.dataset.view));
});
document.querySelectorAll('[data-goto]').forEach(btn => {
  btn.addEventListener('click', () => goto(btn.dataset.goto));
});

/* ---------- Dashboard ---------- */
function greetingText(){
  const h = new Date().getHours();
  if(h < 12) return "Good morning. Let's get something learned.";
  if(h < 17) return "Good afternoon. Pick up where you left off.";
  return "Good evening. One more push before you rest.";
}

function renderDashboard(){
  document.getElementById('greeting').textContent = greetingText();
  document.getElementById('statNotes').textContent = State.notes.length;
  document.getElementById('statCards').textContent = State.cards.length;
  document.getElementById('statMinutes').textContent = State.focusMinutes;

  const due = window.dueCards ? window.dueCards() : [];
  document.getElementById('statDue').textContent = due.length;

  const dueList = document.getElementById('dueList');
  dueList.innerHTML = '';
  if(due.length === 0){
    dueList.innerHTML = '<p class="muted">Nothing due — you\'re caught up.</p>';
  } else {
    due.slice(0,4).forEach(c => {
      const el = document.createElement('div');
      el.className = 'due-item';
      el.innerHTML = `<span>${escapeHtml(c.front.slice(0,40))}</span><small>${escapeHtml(c.deck)}</small>`;
      dueList.appendChild(el);
    });
  }

  const recentList = document.getElementById('recentNotes');
  recentList.innerHTML = '';
  const recent = [...State.notes].sort((a,b) => b.updatedAt - a.updatedAt).slice(0,4);
  if(recent.length === 0){
    recentList.innerHTML = '<p class="muted">No notes yet.</p>';
  } else {
    recent.forEach(n => {
      const el = document.createElement('div');
      el.className = 'recent-item';
      el.innerHTML = `<span>${escapeHtml(n.title || 'Untitled')}</span><small>${escapeHtml(n.subject || '')}</small>`;
      recentList.appendChild(el);
    });
  }
}

function escapeHtml(str){
  const div = document.createElement('div');
  div.textContent = str == null ? '' : String(str);
  return div.innerHTML;
}

function uid(){
  return Date.now().toString(36) + Math.random().toString(36).slice(2,8);
}

document.addEventListener('DOMContentLoaded', () => {
  renderStreak();
  renderDashboard();
});
