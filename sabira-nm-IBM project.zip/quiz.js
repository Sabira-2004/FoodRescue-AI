/* ============================================================
   quiz.js — multiple choice quiz generated from flashcards
   ============================================================ */

let quizQuestions = [];
let quizIndex = 0;
let quizScore = 0;
let quizAnswers = [];

function renderQuizSetup(){
  refreshDeckSelects();
  document.getElementById('quizSetup').hidden = false;
  document.getElementById('quizRunning').hidden = true;
  document.getElementById('quizResult').hidden = true;

  const hint = document.getElementById('quizHint');
  if(State.cards.length < 4){
    hint.textContent = 'Add at least 4 flashcards (across any deck) to build multiple-choice options.';
  } else {
    hint.textContent = '';
  }
}
window.renderQuizSetup = renderQuizSetup;

function buildQuiz(){
  const deck = document.getElementById('quizDeck').value;
  const len = parseInt(document.getElementById('quizLen').value, 10);

  const pool = State.cards.filter(c => deck === 'all' || c.deck === deck);
  if(pool.length < 4){
    document.getElementById('quizHint').textContent = 'Need at least 4 flashcards in this deck to generate multiple-choice options.';
    return false;
  }

  const shuffled = shuffle([...pool]);
  const chosen = shuffled.slice(0, Math.min(len, pool.length));

  quizQuestions = chosen.map(card => {
    const distractorPool = pool.filter(c => c.id !== card.id);
    const distractors = shuffle([...distractorPool]).slice(0, 3).map(c => c.back);
    const options = shuffle([card.back, ...distractors]);
    return { front: card.front, correct: card.back, options };
  });

  quizIndex = 0;
  quizScore = 0;
  quizAnswers = [];
  return true;
}

function renderQuizQuestion(){
  const q = quizQuestions[quizIndex];
  document.getElementById('quizPos').textContent = quizIndex + 1;
  document.getElementById('quizTotal').textContent = quizQuestions.length;
  document.getElementById('quizQuestion').textContent = q.front;

  const optWrap = document.getElementById('quizOptions');
  optWrap.innerHTML = '';
  document.getElementById('quizNextBtn').hidden = true;

  q.options.forEach(opt => {
    const b = document.createElement('button');
    b.className = 'quiz-opt';
    b.textContent = opt;
    b.addEventListener('click', () => handleAnswer(opt, b));
    optWrap.appendChild(b);
  });
}

function handleAnswer(chosen, btnEl){
  const q = quizQuestions[quizIndex];
  const correct = chosen === q.correct;
  if(correct) quizScore++;
  quizAnswers.push({ front: q.front, chosen, correct: q.correct, isRight: correct });

  document.querySelectorAll('.quiz-opt').forEach(b => {
    b.disabled = true;
    if(b.textContent === q.correct) b.classList.add('is-correct');
    else if(b === btnEl) b.classList.add('is-wrong');
  });

  document.getElementById('quizNextBtn').hidden = false;
}

document.getElementById('quizNextBtn').addEventListener('click', () => {
  quizIndex++;
  if(quizIndex >= quizQuestions.length){
    finishQuiz();
  } else {
    renderQuizQuestion();
  }
});

function finishQuiz(){
  document.getElementById('quizRunning').hidden = true;
  document.getElementById('quizResult').hidden = false;
  document.getElementById('scoreText').textContent = `${quizScore} / ${quizQuestions.length}`;

  const review = document.getElementById('quizReview');
  review.innerHTML = '';
  quizAnswers.forEach(a => {
    const el = document.createElement('div');
    el.className = 'qr-item ' + (a.isRight ? 'right' : 'wrong');
    el.innerHTML = a.isRight
      ? `<strong>${escapeHtml(a.front)}</strong> — correct`
      : `<strong>${escapeHtml(a.front)}</strong> — you said "${escapeHtml(a.chosen)}", answer is "${escapeHtml(a.correct)}"`;
    review.appendChild(el);
  });

  bumpStreak();
}

document.getElementById('startQuizBtn').addEventListener('click', () => {
  if(!buildQuiz()) return;
  document.getElementById('quizSetup').hidden = true;
  document.getElementById('quizRunning').hidden = false;
  renderQuizQuestion();
});

document.getElementById('retakeBtn').addEventListener('click', () => {
  renderQuizSetup();
});
