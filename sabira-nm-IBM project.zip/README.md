# Studio — AI Study Assistant

A self-contained study app: notes, flashcards with spaced repetition,
auto-generated practice quizzes, a focus timer, and an optional AI
tutor chat. Pure HTML/CSS/JS — no build step, no server required.

## How to open it

1. Unzip / copy the `study-assistant` folder anywhere.
2. Double-click `index.html` — it opens in your browser and works
   immediately. (Notes, flashcards, and quiz all work fully offline,
   with no key needed.)

If double-clicking causes the AI chat tab specifically to fail with a
network error, run a tiny local server instead (some browsers block
`fetch` from `file://` pages):

```
cd study-assistant
python3 -m http.server 8000
```

then open `http://localhost:8000`.

## Folder structure

```
study-assistant/
├── index.html        entire app shell — all views live in one page
├── css/
│   └── style.css      styling
├── js/
│   ├── app.js          navigation, shared storage helpers, dashboard
│   ├── notes.js         note taking + note → flashcard conversion
│   ├── flashcards.js    deck management + spaced repetition study
│   ├── quiz.js           multiple-choice quiz generator
│   ├── timer.js           pomodoro-style focus timer
│   └── chat.js             AI tutor chat (needs an API key)
└── README.md
```

## Features

- **Notes** — write and organize notes by subject. Everything saves
  to your browser's local storage automatically.
- **Note → Flashcards** — write lines as `Term :: Definition` (or
  `Term - Definition`) inside a note, then click "Turn into
  flashcards" to generate cards from it instantly.
- **Flashcards** — add cards by hand or from notes. Studying grades
  each card *Again / Good / Easy*, which reschedules it using a
  simplified spaced-repetition algorithm (similar in spirit to
  SM-2), so cards you struggle with come back sooner.
- **Practice quiz** — builds multiple-choice questions straight from
  your flashcard decks (needs at least 4 cards in a deck, since 3
  wrong answers are pulled from the deck itself).
- **Focus timer** — pomodoro-style focus/break timer with three
  presets, a session counter, and a day streak that updates when you
  study, review, or complete a focus block.
- **Ask Studio (AI chat)** — an optional chat tab that talks to
  Claude directly from your browser, for explaining concepts,
  summarizing, or generating extra practice questions.

## Setting up the AI chat (optional)

The chat tab needs an Anthropic API key, which is **not** included
(never ship a real API key inside a client-side app that others can
open — anyone could read it from the page source and rack up
charges on it).

1. Get a key from [console.anthropic.com](https://console.anthropic.com).
2. Open the **Ask Studio** tab, expand **API key settings**, paste
   the key in, and click **Save key**.
3. The key is stored only in your browser's `localStorage` — it is
   sent to Anthropic's API and nowhere else, and never leaves your
   machine otherwise.

Everything else (notes, flashcards, quiz, timer) works with no key
and no internet connection at all.

## Data & privacy

All data (notes, cards, timer stats, your API key) lives in your
browser's `localStorage`, scoped to wherever you're serving the
page from. Nothing is sent to any server except the direct,
optional calls to Anthropic's API from the chat tab. Clearing your
browser's site data for this page will erase everything — there's
no cloud backup built in.

## Customizing

- Change the accent colors and fonts in `css/style.css` under the
  `:root` block at the top.
- Change default timer lengths in the `.len-btn` buttons in
  `index.html`.
- Swap the AI model or system prompt in `js/chat.js`.
